# BourseClix

Cockpit de suivi de portefeuille BRVM (actions, obligations, OPCVM, dividendes, alertes) — site statique, sans backend : tout tourne dans le navigateur (localStorage), aucune donnée n'est envoyée à un serveur.

## Pages

- `index.html` — page d'accueil / présentation (marketing, tarifs, FAQ)
- `connexion.html` — connexion / création de compte (démo — n'authentifie pas encore de vrai compte)
- `app.html` — le tableau de bord : portefeuille, marché BRVM (47 valeurs, cours réels), graphique de performance vs indice BRVM Composite, dividendes, alertes, actualités

L'e-mail **yorot225@gmail.com** est reconnu comme compte administrateur (accès illimité, sans essai limité, sans publicité) — voir `ADMIN_EMAIL` dans `connexion.html` et `app.html`.

## Héberger sur GitHub Pages (gratuit)

1. Crée un nouveau dépôt sur GitHub (par exemple `bourseclix`), vide, sans README ni licence.
2. Dans ce dossier, pousse le code vers ce dépôt :

   ```bash
   git remote add origin https://github.com/<ton-compte>/<ton-depot>.git
   git branch -M main
   git push -u origin main
   ```

3. Sur GitHub, va dans **Settings → Pages**.
4. Sous **Build and deployment**, choisis **Deploy from a branch**, branche **main**, dossier **/ (root)**, puis **Save**.
5. Après une minute ou deux, le site est en ligne à l'adresse indiquée sur cette même page (généralement `https://<ton-compte>.github.io/<ton-depot>/`).

L'appli fonctionne alors sur un vrai domaine, en HTTPS, installable sur téléphone ("Ajouter à l'écran d'accueil") — et connexion + tableau de bord partagent désormais la même origine, donc le passage d'informations entre les deux pages est plus simple et plus fiable qu'avec des artefacts séparés.

## Mettre à jour le site

Toute modification des fichiers `.html` poussée sur la branche `main` (ou `docs/` selon la configuration choisie) republie automatiquement le site en quelques dizaines de secondes — pas d'étape de build.

## Limites actuelles

- Les cours de marché sont des valeurs réelles mais figées à la date indiquée dans l'appli (18 septembre 2026) — pas de flux en temps réel.
- La connexion (`connexion.html`) est une démonstration : elle ne vérifie pas de mot de passe contre une vraie base de comptes.
- Les dividendes, alertes et actualités affichés par défaut restent des exemples illustratifs.
